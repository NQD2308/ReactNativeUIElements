import React from "react";
import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
// import { Button } from '@rneui/base';
import { Input, Button, Icon } from "@rneui/themed";

import react from "react";
import { color } from "@rneui/base";
const AwesomeButton = () => <Button title="Welcome" />;

export default function App() {
  const input = React.createRef();

  return (
    <View style={styles.container}>
      <StatusBar style="auto" />
      <Text>Login</Text>
      <Input
        placeholder="Email"
        leftIcon={
          <Icon
            name="email"
            size={24}
            color="black"
            errorMessage="ENTER A VALID ERROR HERE"
            errorStyle={{color: 'red'}}
            
          />
        }
      />
      <Input
      style={styles.inputAccount}
      secureTextEntry={true}
        placeholder="Password"
        leftIcon={
          <Icon
            name="password"
            size={24}
            color="black"
            errorMessage="ENTER A VALID ERROR HERE"
            errorStyle={{color: 'red'}}
            
          />
        }
      />
      <Button title="Solid" color="warning" size="lg">
        Button
      </Button>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  inputAccount: {
    width: "80%"
  }
});
